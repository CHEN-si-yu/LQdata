# 因子注册与落盘说明

本文件说明当前运行清单和输出合同，替代[旧版因子库快照](archive/legacy/因子库快照_20261007前.md)的“最新数量”与操作说明。运行方式见[项目手册](项目手册.md)，历史研究结论见[历史分类索引](archive/README.md)。

## 当前清单如何读取

```bash
python main.py list
python main.py status
```

两者显示全部启用注册规格、group 及本地台账覆盖，包括研究转正实现。它们不扫描年度文件、不做评估，也不自动刷新旧字典。

2026-10-08 R15 收尾交付时，直接调用当前 `registered_specs` 得到以下快照：

| 类型 | 启用数 |
|---|---:|
| 股票因子 | 258 |
| 市场因子 | 47 |
| 标签 | 5 |
| 总计 | 310 |

这是注册数量，不是有效或盈利数量；但本轮 229→258 的 29 个新增对象均已完成正式工程验证、当前库 G5、主审裁决、生产物化与逐值对拍（见[收尾交付总结](因子研究R15收尾交付_20261008.md)）。后续以实际注册表为准；历史记录中的 149、180、208、227、257 等计数各属当时阶段，不能合并或当作当前结果。在途未完成方向见[冻结记录](因子研究方向冻结记录_20261008.md)。

## 注册来源

当前加载器为 [fea/production.py](../fea/production.py) 的 `registered_specs`：

1. 导入 [factors/__init__.py](../factors/__init__.py)，加载内置 `@register(FactorSpec(...))` 规格。
2. 从 [conf/production.json](../conf/production.json) 中读取状态为 `production` 的历史研究对象。
3. 对不在内置注册表中的研究对象，读取 `artifacts/research/catalog/candidates/<candidate_id>.json` 的冻结定义，按其 `research.<module>:<builder>` 构造规格。
4. 返回 `enabled=True` 的规格。因子选择再沿父依赖拓扑展开。

上述冻结定义和实现模块是生产输入依赖，不能当临时研究证据删除。清单只用于找到原有生产实现，不在每次生产核验批准哈希或重新审核。历史字典 `artifacts/catalog/factors.csv`、旧发布清单和 `current_release.json` 不随新入口更新。

## 增加或修改因子

新增内置规格时，在 `factors/` 模块用 `@register(FactorSpec(...))` 装饰计算函数，并确保该模块由 `factors/__init__.py` 导入。单独调用 `register(FactorSpec(...))` 不会完成函数注册。

规格声明 name、group、直接输入和父依赖、真实值起点、日历天预热、方向与必要的财务字段等。函数从 Context 读取输入，返回股票 `(T,C)` 或市场 `(T,)` 数组，经 Engine/Store 统一落盘；不自定义分区格式或任意访问业务文件。可得性滞后的输入遵守 `lagged_ok` 与实际位移口径。

新的启用注册对象没有覆盖，默认运行会补请求范围历史，已有对象继续按覆盖跳过。父依赖加入选择集并在子对象前完成。新增注册不触发其他无关因子重算，也不代表新的研究有效性结论。

修改既有公式应记录规格版本和口径，并显式执行 `rebuild`；仅提高 `version` 不会在当前入口自动失效旧覆盖。历史源修订使用限定日期的 `--refresh`。共享数值逻辑变更应明确所有受影响对象并隔离验证，避免让旧覆盖混入新口径。

## 输出合同

| 类型 | 路径 | 固定列序 |
|---|---|---|
| 股票因子 | `data/factors/<name>/year=YYYY/data.parquet` | `trade_date, stock_code, value, rank` |
| 标签 | 同上 | 同上，rank 恒为 NaN |
| 市场因子 | `data/market_factors/<name>/year=YYYY/data.parquet` | `trade_date, value` |

日期与股票代码使用 string，value/rank 使用 float32；计算内部沿用 float64。股票/标签按日期和股票代码排序，市场按日期排序，当前压缩为 zstd。股票轴来自固定名单，日期轴来自本地交易日历；缺测保留 NaN 和完整键轴。真实值起点前的对齐前缀沿用原规格，不通过删除空年份或空行缩小任务。

年度文件由原子写入更新。增量按本次日期替换并保留其余行，明确日期的历史刷新保留后来日期。状态 `state/<name>.json` 保存覆盖、分区信息与未完成年份，不执行内容指纹。

落盘合同实现在 [fea/store.py](../fea/store.py)，公式和 PIT 由 [fea/engine.py](../fea/engine.py) 延续。既有数值及 Parquet 字节一致证据见[生产重构验证记录](生产重构验证_20261007.md)。
