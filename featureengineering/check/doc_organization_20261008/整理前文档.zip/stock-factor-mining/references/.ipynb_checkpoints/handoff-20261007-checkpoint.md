# R14 暂停交接快照

生成日期：2026-10-07。用户当前只授权快速整理 SKILL，其他研究停止。此清单是交接线索，不能自动恢复计算或作为新的主审结论。接手者应核验最新注册、进程和产物；其他维护工作可能已更新生产代码。

## 入口与账本

- 研究目录：`artifacts/research/round14_20261007/`（下称 R14）。
- 主审台账：`R14/chief_ledger.json`；定义/政策冻结、各席位报告与 job JSON 保留。该台账尚未吸收所有最新交付，不能直接把其数字当最终已研究总数。
- 历史研究说明：`doc/因子研究R14_20261007.md`。
- 生产保持 `main.py` 直接生产，研究入口为 `scripts/research_cli.py`。
- 五席位为 price、finance、events、microstructure、network；实际同时只允许主审加3子 Agent。当前不再派新任务。
- 暂停检查发现正式研究计算均已退出；剩余资源监控 PID 108364 已发送 TERM。后续重新读取进程状态，不依赖这个历史 PID。

## 已批准且实际落盘的两项

| 因子 | 正式候选ID | 封存 run |
|---|---|---|
| F001 CCC季节趋势创新 | `r14f1_ccc_seasonal_trend_innovation_v2_0a98f6e1fc8b0970` | `r_c08d93b840e94e2cb8c82e340398e170` |
| P006 原始月收益前景效用 | `r14p6_raw_monthly_tk_v1_dee5c4eeffeaaa9f` | `r_c88bde0ce60f4623bf41ab61f4183418` |

两项9年年度文件均已与封存输出精确对拍；历史股票因子数由227增至229。这个数量是两项完成时的快照，当前总数从真实注册获取。

证据：F001 `seat2_finance/chief_admission_v1.json`、`production_compare_v1.json`；P006 `seat1_price/p006_chief_admission_v1.json`、`p006_production_compare_v1.json`。

## 正式计算和工程验证已有结果，尚待完整主审

| 方向 | 状态及下一步 |
|---|---|
| M002 GC 日内非流动性不对称 | `seat4_microstructure/m002_formal_evidence_v1.json` 显示工程passed=true，run `r_dd7db74f98df480681abf2b5e72ab9e3`，verify `v_1b9b0527ceef458db504381126f06737`。需将旧227对象 G5 扩展到当前全库，独立主审后才能晋级。 |
| F007 GC 正合同权利份额 | `seat2_finance/batch2/f007_formal_evidence_v1.json` 工程passed=true，run `r_3ef40216df2b4c6ab66321ae5cfd516a`，verify `v_c1c7f65cd9794f7481d3c726ba1f5cb7`。需当前全库G5和主审。 |
| P007 GC 带符号金额反转斜率 v2 | ID `r14p7_signed_amount_reversal_v2_7dd5dbc630f5495e`，`jobs/p007_v2_formal_run_v1.json` complete。从实际日志读取runID，再做封存值对拍与真实verify；当前229对象G5曾完成。 |
| P009 GC 负冲击方差反馈 v2 | ID `r14p9_negative_shock_variance_feedback_v2_d4ad4585f4444283`，`jobs/p009_v2_formal_run_v1.json` complete。下一步同P007。v1有端点缺陷，不能拿v1证据替代。 |
| P011 GC 市场下尾共同出现 v2 | ID `r14p11_market_lower_tail_coincidence_v2_d02a562b871b1976`；先查最新G5作业和是否存在正式run，不能重复启动。 |

M002/F007 工程通过是在本次编写 SKILL 时读取真实 JSON 确认的；没有在本次文档任务里执行晋级或生产。

## 新交付与初筛结论

- **N006**：`seat5_network/n006_full_v41_screen.json`，原方向G4失败，h1 t=.1156、h5 t=-.5459。研究员建议拒绝；主审需吸收进台账。
- **N007**：`seat5_network/n007_full_v41_screen.json`，h1单项和BASE8过，家族补控双核反转，建议拒绝独立增量。原覆盖/G3复审不得重复计方向。
- **N014**：`seat5_network/n014_full_v41_screen.json`，全期质量通过，h5家族补控两核通过且弱增量；还缺当前全库G5、结构主审、Catalog正式工程。入口报告 `report_full_v41.md`、`full_v41_outcomes.json`。
- **M013/M014**：`seat4_microstructure/history_handoff.md`、`history_handoff_manifest.json`；全期float32数组2123×2115，有效率约99.299%/99.288%，每天至少100股且非恒定。六份定义和纯builder已准备未注册。正式年度适配器精确对拍，峰值4.68GiB；仍缺全库G5与正式cutoff/增量。建议jobs1/reserve8，不能直接采用研究扫描低RSS配置。
- **F015**：`seat2_finance/batch4/f015_closure.json`、`formal_f015/`；少数股东资本现金份额，已做官方单位对账与全期覆盖，未正式注册。还需结构/全库G5/正式工程。
- **P013/P014**：`seat1_price/report_batch4.md`、`outcomes_batch4.json`；无标签识别探针通过一定质量，分别全年50股覆盖89.68%/88.17%。需主审决定全期固定GC质量升级，不视为已准入。
- **P016**：同报告有弱识别、边界、null 假阳性；建议不扩大。
- **P015**：原文公式未取得且与P004机制区别未解决，继续design/source hold。
- **F027/F028/F029**：财务第四批新方向，见 `seat2_finance/batch4/directions.json`、`report.md`。只有升级建议，不是已检验；F029年度口径变更有事前记录，需要阅读后再决定。
- **E026–E033**：事件第四批已交付，见 `seat3_events/batch4_report.md`。多数缺必要历史输入，E032质量失败；应独立审核后计入关闭方向。未填写的后续编号不计完成。

## 恢复研发时的顺序

先获得用户明确恢复指令；核验当前代码/政策/输入/注册和资源，再整理未吸收裁决。优先完成已具正式工程证据的主审和已有run的对拍，随后审核N014与M013/M014等交付。新增方向不应挤占已有证据的收尾。

严禁看到“engineering_passed=true”就直接晋级。若新入库对象增多，所有待审G5重新扩展；若共享核心变更，检查已有run计算身份能否继续封存verify，不能绕过identity检查。
