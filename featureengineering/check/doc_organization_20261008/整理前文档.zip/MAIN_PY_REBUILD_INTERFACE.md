# main.py 入口命令说明

对齐 2026-10-07 的实际参数解析与生产调度。无参数直接增量计算；因子输出合同见[项目手册](项目手册.md)。[旧版接口](archive/legacy/入口接口_20261007前.md)仅用于历史追溯。

## 命令

| 命令 | 别名 | 作用 |
|---|---|---|
| `run` | `incremental` | 补缺口、新日期及标签未成熟尾部；跳过已对齐对象 |
| `rebuild` | `full` | 强制重算选定对象与日期范围 |
| `list` | — | 显示全部启用注册对象、类别和台账覆盖 |
| `status` | — | 与 `list` 相同 |

无参数或只传生产选项会自动采用 `run`，例如 `python main.py --jobs 8`。全局 `-v/--verbose` 应放在命令前；详细日志会同时输出到终端。帮助查看：

```bash
python main.py --help
python main.py run --help
python main.py rebuild --help
```

## run/rebuild 参数

| 参数 | 默认值 | 语义 |
|---|---|---|
| 位置参数 `names ...` | 全部启用对象 | 按名称选择；自动补入父依赖 |
| `--factors NAME ...` | 未指定 | 按名称选择，优先于位置名称 |
| `--group GROUP ...` | 全部类别 | 无名称选择时按 `FactorSpec.group` 筛选；不是来源类型筛选 |
| `--jobs N` | `0` | 0 使用配置默认；当前默认 12、上限 20，并受 CPU/内存约束 |
| `--start YYYY-MM-DD` | 配置对齐起点 | 输出请求起点；父依赖可能扩展到预热范围 |
| `--end YYYY-MM-DD` | 源最新交易日 | 输出请求终点，始终不超过源截止 |
| `--from-year YYYY` | 未指定 | 起点取当年 1 月 1 日，覆盖 `--start` |
| `--to-year YYYY` | 未指定 | 终点取当年 12 月 31 日，覆盖 `--end` |
| `--refresh` | 关闭 | 强制重算请求范围，保留范围外数据 |
| `--resume` | 关闭 | 将 rebuild 改为按覆盖补剩余部分；不与 `--refresh` 一起用于断点恢复 |
| `--sandbox DIR` | 正式项目目录 | 全部运行产物落入项目内独立子目录；保留只读原始输入与合同 |
| `--progress MODE` | `auto` | `auto/bars/plain/off`，见下文 |
| `--dry-run` | 关闭 | 只规划，不生成因子或提交覆盖；仍创建日志和锁文件 |

`list/status` 只支持 `--sandbox DIR`，不支持日期、类别或因子选择。名称列表可用 `list` 查询；类别是实际规格的 group，例如 `market`、`momentum`、`quality`、`label`。选择子因子时父依赖即使不属于所选类别也会加入。

日期必须为 `YYYY-MM-DD`。从源截止之前的有效交易日生成输出，不填造未来交易日。开始晚于请求/源截止时报错；请求内没有交易日时不生成新分区。

## 常见场景

```bash
# 每日增量；首次运行也用同一入口补历史
python main.py

# 只计算点名对象；按类别计算
python main.py run momentum_20 roe_ttm
python main.py run --group market label

# 明确强制重算
python main.py rebuild --factors momentum_20
python main.py rebuild --from-year 2025 --to-year 2026

# 上游修订：精确限定输出日期
python main.py run momentum_20 --start 2026-09-01 --end 2026-09-30 --refresh

# 中断恢复：按已提交断点补齐
python main.py
python main.py rebuild --factors momentum_20 --resume

# 隔离查看/生成；所有输出仍在项目内
python main.py run momentum_20 --sandbox artifacts/tests/my_run --start 2026-09-01 --end 2026-09-04 --dry-run
python main.py run momentum_20 --sandbox artifacts/tests/my_run --start 2026-09-01 --end 2026-09-04
python main.py status --sandbox artifacts/tests/my_run
```

`rebuild --resume` 不验证公式是否改变，已有覆盖仍视为完成。公式修改应先用明确选择范围的 `rebuild`；启动重建后若中断，再按同一输出目录与对象范围恢复。再次运行不带 `--resume` 的 `rebuild` 会重新计算整个请求范围。

局部更新保留其他日期和年份。父依赖预热可能扩大父对象的计算范围，子对象仍按自身请求轴输出。更新一个父对象时，未被选择的其他子对象不会自动加入；公式修改应显式选择受影响的对象。

## 进度、日志和退出码

| 模式 | 展示 |
|---|---|
| `auto` | 标准错误为终端时用 tqdm，否则用对齐文本 |
| `bars` | 强制总进度和逐因子多行条 |
| `plain` | 时间戳、阶段摘要、对齐因子清单与年任务完成记录 |
| `off` | 保留日志路径和阶段摘要 |

```bash
python main.py --progress plain
python main.py --progress bars
python main.py --progress off
```

后台日志采用 `--progress plain`，或同时重定向标准输出与标准错误。进度按年任务完成提交，单个长任务执行期间主要显示状态与心跳，不代表逐行计算进度。已知空窗口/自由度不足的数值提示在计算进程中定向忽略，NaN 语义不变；其他警告及计算异常保留。

日志位置在启动时打印，默认 `logs/run_factors_*.log`。正常调度结束后写 `state/production_last_run.json`；异常退出不保证刷新该摘要，断点以逐因子状态为准。

| 退出码 | 含义 |
|---|---|
| `0` | 成功、全部跳过，或计划查看完成 |
| `1` | 计算/配置/数据错误，或有失败及阻塞对象 |
| `2` | 参数解析失败或同目录写入锁冲突 |
| `130` | 用户中断 |

历史接口中的评估、审核、发布、字典与资源命令不再由本入口提供。生产不执行旧哈希批准或发布指针更新；不能按旧文档中的同名参数推断当前行为。
