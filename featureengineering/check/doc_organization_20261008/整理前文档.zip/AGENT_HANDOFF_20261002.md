> 注（2026-10-03）：本文档现位于 doc/ 目录；文中出现的相对路径均以项目根为基准。

# 因子工程复审与清理交接 — 2026-10-02 用户关机重启前

## 0. 当前状态与阅读顺序

**本次任务已按用户要求停止，当前没有本任务仍在运行的计算、调度、监控或缓存辅助程序。不要把主动中断计为因子失败。** 数学计算于服务器时间 2026-10-02 23:47:39 开始停止；辅助程序补查与最后进程验证时间为 23:53:10。尚未实施因子剔除、生产源码修改或最终清理。本文件由用户明确要求新增，不属于数值实现变更。

先阅读本文件、项目根目录 `AGENTS.md`、`README.md`；再核对下述持久化快照与原始证据。本文件是恢复路线图，具体数值、候选身份、哈希和运行完成状态以原生封存记录为准。不要从旧状态文字或残留年度分区推断验证成功。

路径约定：

- 用户指定项目目录：`/root/autodl-fs/featureengineering`。
- 实际解析目录 ROOT：`/autodl-fs/data/featureengineering`，两者指向同一项目。
- 本轮证据目录 B：`ROOT/artifacts/research/legacy_gates_20261002`。
- Python：`/autodl-fs/data/miniconda3/bin/python`，当前实际环境 Python 3.14.7、NumPy 2.5.3，环境指纹记录中为 `7c7d05c7564f`。重启后重新核对，别换环境重用旧证据。
- 服务器 SSH：`ssh -p 56179 root@connect.westc.seetacloud.com`。本文件不保存密码或密钥。
- 当前原始生产发布：`12424aa8910771a42333d8201b51d22c8fc05988c66c8b6960e95385649c2a26`，截止日 2026-09-30；见 `state/current_release.json`。还不是清理后的新发布。
- **最新停止事实**：`B/user_stop_snapshot_20261002.json` 和 `B/driver_state.json`，状态 `stopped_at_user_request`，剩余所属进程为 0。
- `/tmp/legacy_gates_20261002` 只是本地临时状态与副本，重启可能消失；以 B 内持久化文件恢复。

## 1. 用户目标、授权与边界

用户要求理解昨天新设严格审批框架，并按相同规则复审此前已入库全部因子；分批计算，高效使用服务器，逐渐增大并行。**全服务器容器计入内存的上限是十进制 60 GB，即 60,000,000,000 字节，不是 60 GiB。**

用户进一步明确：等所有需要的测试、最终机制审议完成后，将所有不通过的因子从现有工程清除，文档可以记录名称、结论与说明，但其余独立脚本、数据文件和生成缓存都删；只保留批准因子。该清理已获授权，不需要再询问同样的批准。现在的最新指令是停机交接，因此本轮不再续算或清理。

清理不能仅改状态或隐藏注册项，不能把失败源码/数据装进 ZIP 当作备份继续保留。需要保留批准因子必要的共用数学原语、私有计算基元和真实上游 RAW；不能误删上游数据、其他任务文件或共享依赖。Revise/待确认如果最终没有合格证据，也不能当成通过继续作为独立因子保留。禁止为了通过而事后改方向、放宽门槛、假造历史日期或只选择好年份。

## 2. 准确进度：不是最终保留数量

| 当前口径 | 最低测试或结构合同通过 | 等待确认/完成 | 已不通过 | 合计 |
| --- | ---: | ---: | ---: | ---: |
| 股票因子 | 77 | 23 | 388 | 488 |
| 市场上下文与收益标签 | 66 | 0 | 0 | 66 |
| 全工程对象 | **143** | **23** | **388** | **554** |

解释：

- 66 个非股票对象 = 61 市场上下文 + 5 收益标签；通过其适用的结构合同。它们不是 66 个已证明独立 alpha 的股票因子。
- 23 个股票待确认 = **12 个重源 G1 尚未完成** + **11 个单期限显著/Revise，需要最终按既定规则裁决**。
- 388 = 386 个统计/适用规则拒绝 + 2 个真实 G1 审计合同失败。
- 77 股票最低测试通过仍需逐因子最终机制和分年稳定性审议；实际最终保留数可能下降。**最终机制审议尚未运行，不能宣布143是最终批准数。**
- G1 计划共 91 个目标，79 已完成：77 通过、2 真实失败；12 未完成。其中74个完成全新实算三阶段验证，另3个研究因子使用经实际重新核验可复用的原生历史证据。
- 当前封存的单阶段结果计数：全量 calculation 76、真实截断 causal_truncation 75、两阶段增量 incremental_validation 74。阶段数量不等于完整 G1 目标数。
- `B/review.json` 仍是 `statistics_complete_engineering_pending`；尚未 finalize。

已完成：

1. 原生生产恢复覆盖2018—2026全部9年，554对象发布；之后生产没有本任务活跃构建。
2. 554结构、固定网格、类型、无Inf、前缀rank检查完成。
3. 488股票统计筛选、两期限IC及增量FM完成。
4. 22个粗相关分块、118,828对筛查完成。
5. 93个可能进入G5审查目标对其余487对象全部2123日精确穷尽比较完成；2个稀疏事件条件方向翻转被拒，留下91个G1目标。
6. 79个G1目标完成。
7. 清理前注册/文件/源码依赖盘点完成；必要私有父子计算可行性只读验证完成，见第7节。
8. 清理方案、交付程序已有草稿，均未实际执行清理或生成最终交付。

## 3. 停止时的5项实算与剩余12个G1目标

以下5项确实正在计算，被用户主动停止；旧 *_progress.json 可能仍写 running/passed:false，这是进度快照，不是拒绝结论。

| 原名 | 停止阶段 | 已完成可进一步核验的部分 | 中断请求文件（B/engineering/下） |
| --- | --- | --- | --- |
| close30_ret | incremental_validation | 全量与真实截断已封存；增量中断 | phase_0b4e402308f446dcb9eddb56ce99df1b_request.json |
| id2_close_vs_pm_vwap | causal_truncation | 全量已封存；截断中断，增量未开始 | phase_20230fd110ec45a996a7b2fc12cdb1e8_request.json |
| id2_close_vs_pm_vwap_20 | calculation | 全量未封存 | phase_ea7b4e64dcc74ae99ffb1be36a393fd7_request.json |
| id2_hi_lo_pos_gap | calculation | 全量未封存 | phase_bfe45d62a9374efba3d1c0ab8ed9de14_request.json |
| id2_parkinson_vol | calculation | 4→5并行后刚开始的全量，未封存 | phase_6d093111b51042d091cd95085a379546_request.json |

全量参考：
- close30_ret：`r_b533e5aaaa364427b579228a8076db8e`，alias `la26_close30_ret_v1_d2bf2244cdaa33e3`。
- id2_close_vs_pm_vwap：`r_c4560b93e5354486a165091d2c69f078`，alias `la26_id2_close_vs_pm_vwap_v1_3434e4bd426f645d`。
- 其余alias、请求参数、PID/start/PG及完整中断列表见停止快照和 `engineering/plan.json`。
- 增量实际段末 `[20231229,20260930]`；截断日2023-12-29；全量2018-01-02到2026-09-30（请求起点有2018-01-01字符串，最终按原生交易日）。

全部12个尚未完成G1的原名：

```text
close30_ret
id2_close_vs_pm_vwap
id2_close_vs_pm_vwap_20
id2_hi_lo_pos_gap
id2_parkinson_vol
id2_ret_concentration
idt_rv_daily
idt_rv_term_structure_slope
idt_vol_stability
mfx_minute_weighted_pressure
open5_capacity_floor_ratio_20
r3b_intraday_rv_skewness_v2_44ef55d83a759fba
```

最后7项在停止时没有活跃新阶段；mfx_minute_weighted_pressure属于tdx_minute，不能套用stock_history_5min的并行探针结论。

11个待最终裁决的单期限/Revise对象：

```text
afx_bs_oth_comp_income
afx_fi_saleexp_to_gr
cf_net_borrowing_to_assets
chip_win_peak_frac
cp_bigflow_margin_20
cp_moneyflow_momentum_res
cyqp_winner_fraction
ind_disp_ma_5d
mf_net_amount_intensity
mf_vol_amount_divergence
panic_selling_ratio_60
```

## 4. 审核规则与关键计算口径

固定股票池2115只，2123个交易日，2018-01-02至2026-09-30。股票池有存续/ST选择限制，应在结论中披露，不能把结果称为全市场可交易盈利证明。供应商当年历史版本也尚未被证明。

- **G1 真实工程因果一致性**：从真实RAW执行全量、真实截断、两阶段增量，比较键、网格、NaN位置、float32 value/rank精确一致；没有Inf，不允许全NaN伪验证。生产原值与研究alias全量也精确比较。封存run、来源身份、参数/方向、原生verification缺一不可。
- **G2 覆盖**：全日历至少60%日期上有至少100股票有效值，尊重真实开始日期。
- **G3 非常量**：至少95%有效活动日期横截面非常量。
- **G4 IC**：在同一个h=1或h=5上，声明方向的HAC95%下界>0，且9年中至少7年正向、每年至少60有效观察；不能跨期限拼条件。
- **G5 去重**：排除自身，对全部其他股票对象取日横截面相关的时间均值；abs(mean daily rho)≤0.95，超过0.9需要机制解释。mean(abs(daily rho))仅诊断，不能替代阈值。
- **G6 逐年剔除稳定性**：所有leave-one-year-out的IC/FM均值在同一主期限正向，不能主要靠一两年。
- **G7 增量**：日完整案例，rank总体z标准化，1/99 winsor，clip10，带截距截面OLS；FM beta序列HAC19、block20。基准控制：mom120、reversal5、vol120、idio60、log_mv、turnover_std20、bp、roeTTM。约53个价格/波动候选另加idt_rv_daily、id2_parkinson_vol、var95；候选若为自身控制则移除自身项。遵循昨天R3单期限Revise先例：**h1与h5的增量CI都必须正向**。年度FM正向年份C也应两期限均≥7/9；混合或不足不能称稳定。
- IC最少30配对，FM最少100完整案例，标签用raw值。股票/标签4列：date、字符串code、float32 value/rank；标签rank为NaN。市场2列合同。
- 同时存RAW与DECL方向结果。evaluation.rankic已是声明方向；函数可能本身已负号，不能二次翻号。
- 稀疏因子中位零比例>10%时，把非事件零当NaN做条件IC/FM；主期限条件翻负阻断事件机制。不是简单删除所有零值就算更好。
- 原生研究自动promotion只有G1+60obs等门槛，**不是本次完整G2–G7最终审批**。不能以production/shadow状态代替严格审议。
- 控制变量本身也不能获统计失败豁免；必要控制的数学基元可私有保留，失败独立因子输出仍应删除。
- 不新增“弱IC幅度”硬门槛，不事后翻方向，不做下游模型训练。

两项真实G1失败：`rel_turnover_ind_20d`、`rel_vol_ind_20d`。实际在读取tdx_blocks时被缺少有效历史可得日期的RAW审计合同拒绝，未完成全量封存，更没有截断或增量通过。行业实现 `_ind_boards` 读tdx_blocks/dc_blocks**指数类别字典，不是当前股票成分**；`_assign` 按年用年初之前[Y−2,Y−1]日收益推定归属。本次失败是字典历史版本/静态元数据合同缺证，不能写成“已证实用当前成分回填历史”。不假造日期或加白名单绕过。

G5条件方向拒绝：close30_crowded_fade、gap_fill_tendency_10d。G2股票均通过；G3中afx_is_fin_exp_int_inc非常量比例约0.8765897失败；G4通过152对象。

## 5. 并行、内存与资源经验：实际达到什么

CPU配额32，容器物理/配额约64.42GB；用户60GB更严格。记账按cgroup memory.current，包含anon、页缓存等，不能仅看进程RSS或空闲内存。全程producer+sampler记录最大53,966,264,074字节，约53.966GB，低于60GB；其中生产日志GiB峰值有0.01GiB舍入，该汇总不是全部精确采样字节的倍数。审计控制器单独历史峰值约43.519GB，不是全程最大。

实际轻源候选并行2→4→8→12→16→20，**没有实际24并行**。轻源20阶段CPU约19.1—19.6核，内存约43.8GB。重源stock_history_5min实际1→2→3→4→5；停止前最大是5，项目策略允许最多12但未达到12。

重源真实升级窗口：

| 升级 | 实测窗口秒 | 本任务平均CPU核 | peak charged GB | peak anon GB | 新封存原生阶段 | 新完整G1通过 | 新完成原生年度分区 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 2→3，23:20:59 | 600.0544 | 2.0179003 | 29.064654848 | 7.465725952 | 2 | 0 | 3 |
| 3→4，23:30:59 | 600.0998 | 3.0222475 | 30.834479104 | 9.566216192 | 0 | 0 | 4 |
| 4→5，23:46:50 | 600.1330 | 4.0084614 | 29.970272256 | 12.483891200 | 0 | 0 | 7 |

这些年度分区是**资源推进证据，不是G1证明**。最后窗口见 `B/engineering/elastic_progress_v10_heavy.json`；前序V9/V8等文件在同engineering目录。

继续时的策略：

1. 每种RAW输入类型重新起1个新pilot，尤其重启后缓存冷态；同型逐级加1，只在有剩余任务时升级。
2. ≥600秒新的真实测量窗口，本任务CPU均值≥0.65×当前cap，有≥cap新封存阶段或真实候选年度分区推进。不得把合成counter测试或文件存在当实算完成。
3. 预测 `peak_nonanon + peak_anon*(next/prior) + 4GB reserve < 47GB`，预测anon<40GB；避免以冷缓存瞬时小内存直接高并行。
4. 当前charged≥40GB暂停新增启动，已有程序继续；独立保护每0.25秒监视，charged≥50.5GB或anon≥48GB就停止**本任务所属数学进程组**。保持用户60GB安全余量。
5. 每个原生数值phase新进程，原有24GiB RLIMIT_AS不提高，数值线程1，candidate jobs=1。worker代码里memory_budget_gib=52不是60GB硬上限，必须配独立cgroup保护。
6. 保护进程独立于调度器；按实际PID+start time+PG识别归属，不全局pkill、不按旧PID直接杀。
7. 启动前核对可用磁盘与inode。当前23:51:58可用磁盘67,673,546,752字节；恢复时必须重新读。原生phase保留4GB、4000inode下限。
8. resource-counter遇到共享盘年度文件刚改名消失应跳过重试，不能导致保护器退出；不改数学审核。

冻结源码 `B/engineering_parallel_amendment_v13.json` 共36项，23:52核验全部SHA一致。V13只追加orchestrator_v10/driver_v13，原数值worker与原生verifier未改。恢复新调度应另存新版本和source seal，保留原36；不要为了恢复去改已封存数值实现。

原V13 driver PID113096/start6248309668、stage113099/start6248309742均已停止，所有原采用PG及5数学子阶段已停止。监视、resource_sampler_v2、own_cache_pressure_v2、reclaim_owned_derived_v2、completed_trial_page_advice_v1也已停止。**严禁直接运行audit_driver_resume_v13.py恢复：它假设旧控制器与采用进程仍活着，会检查/暂停旧PID；重启后应构建零活跃采用的新调度器与保护器。** 旧handoff/adoption只是历史身份，不能复活进程。

## 6. 重启后如何恢复未完成验证

按顺序实施，不要一上线就重跑全部554或删除目录：

1. 核对ROOT解析路径、Python/依赖指纹、当前发布、上游RAW身份、freeze、36源码SHA、完整目标结果与停止快照。补查是否有其他来源的生产进程或重启自启任务；只控制自己任务。
2. 对91目标逐一读取 `B/engineering/<original>.json`。必须有passed明确值且完成证据闭合才是目标结果；*_progress.json不是通过结果。主动停止请求保持pending，不将returncode SIGTERM写成统计/源合同失败。
3. 建立新的独立资源保护与新调度版本，使用BASE持久状态、本地tmp原子状态与三份关键证据，封存新增调度代码；不要在共享FUSE上反复依赖原子rename保存唯一权威状态。
4. **恢复代码需要实际实现，当前没有现成自动断点续phase逻辑。** `engineering_audit.worker` 仅能跳过已有完整target.json；对pending会重新启动全量。`isolated_run`每次生成新uuid，原始实现不自动复用close30/id2已封存阶段。如果想节约重算，应做独立新resume wrapper：验证每个旧phase result、run.json完成状态、来源/参数/日期/kind、输入输出哈希、版本身份与精确比较适用性后，在原生verify_candidate流程中返回该封存实算run；匹配请求必须严格，旧阶段只能用一次且不能随意跨目标。必须真正补算中断/缺失阶段并运行原生精确截断/增量比较和生产全量parity。如果不能可靠实现/验证复用，就用原worker重新全量，允许多算，不能省略证据。
5. 未封存部分、增量中断目录、partial年度分区只能视为残留；保留隔离记录，在新的run/candidate目录重算。不要写假run.json、移植部分输出冒充完成，避免共享目录碰撞。
6. 优先完成close30增量、id2_close_vs_pm_vwap截断/增量；再其他重源，依第5节同型逐步加并行。tdx_minute另起pilot。原始候选alias见plan，参数、方向不得修改；close30 alias的warmup0→1日审计取数调整已有真实数值parity证据要求，不改生产公式。
7. 两个已确证G1合同失败保持拒绝。除非有真正新增历史字典证据，不反复盲试、不放宽门槛。11个单期限Revise不需要浪费全套重源G1来挽救统计缺陷。
8. 所有91目标处理齐全、资源失败另行正确重试/分类之后才执行原 `engineering_audit.finalize`，它本身不检查“所有目标齐全”，调用前需加完整性核对。finalize中的旧“无需不可逆修剪”文字早于用户清理授权，不能当成禁止执行用户已授权清理。
9. 更新review/final_summary并做最终机制审议；然后才进入清理。继续定期简洁报告真实通过/待确认/不通过数量，区分最低通过与最终批准。

## 7. 最终机制审议已准备，尚未执行

`B/mechanism_candidates.json` 收集候选真实源码/参数/指标，约1.9MB，包含源码快照，后续用户清理后不能整份打包作为失败源码备份；应提炼成纯说明/指标文档，清理不批准的源码内容。

已有草稿发现8个当前最低通过对象年度FM C不满足“两期限均≥7/9”（应核对原记录再裁决）：

| 原名 | h1/h5正向年份 |
| --- | --- |
| afx_fi_q_op_yoy | 7/6 |
| cfcr | 5/5 |
| dv_stability_4q | 5/5 |
| ind_int_to_talcap | 6/6 |
| mf_big_mid_net_corr_20 | 6/9 |
| mf_flow_factor_momentum_20 | 6/8 |
| overnight_gap_vol_20 | 8/6 |
| short_balance_ratio_change_20d | 7/6 |

机制尚需明确的4个：afx_fi_daa、mfx_index_pressure、mfx_ths_gap、mfx_minute_weighted_pressure。压力/行业gap相关是暴露代理，不能仅凭显著就视为收益方向机制。afx_fi_daa是折旧摊销/投入资本，正向统计9/9不自动说明原方向合理。

afx_cf_im_net_cashflow_oper_act此前误以为现金绝对规模后提出疑问，已按真实源码纠正：间接法经营净现金流/经营现金流入总额，已公告年报、asinh压缩，可解释经营现金留存/转化质量，FM8/8；从机制Revise草案移出。这是纠正源码理解，没有翻号、换参数或新造门槛。

afx_fi_ocf_to_interestdebt、afx_fi_ocf_to_opincome、afx_fi_q_netprofit_qoq、afx_fi_q_ocf_to_or、qf_cash_margin_yoy_change低IC幅度仅作限制说明，不能新设最低幅度拒绝。实际ATR是14日，不是旧文字20日；dv_stability_4q实际dv_ttm250日CV/min_count60/无clip；extreme_move_event阈值7%；id2_hi_lo_pos_gap是出现位置差绝对值。保留真实实现与旧描述差异说明。

研究锚当前FM t（h1/h5）：fragility原raw负而DECL正9.0173/8.2771，HIB=False；HHI12.2067/7.2931；R2趋势持续性4.74136/4.52566（早期summary1.58/1.83不是当前）；R3负已实现偏度9.40286/9.27204，函数已负号HIB=True。R3使用去隔夜5分钟去均值收益、BPV pi/2、±6sqrt(BPV/N)阈值截尾，不能二次翻号。这些是当前统计，R3本轮G1仍pending。

dragon_tiger_org_net_20的固定股票池机构源：2018约94.32%、2019约24.11%的可比行buy−sell与Net符号相反，2020/2025为0；这是特定源/年份实际诊断，不能替其他龙虎榜项做空白一刀切拒绝，未修正RAW。证据文档应准确标明适用范围。

## 8. 清理依赖：已验证事实与必须完成的工程

盘点：`cleanup_preinventory.json`（554注册对象、函数依赖、moduleSHA）、`cleanup_scope_inventory.json`（正式data/state、408研究run、5研究配置、16审计目录）、`cleanup_source_plan.json`（43模块、219潜在静态失败定义）。源码在ROOT/factors，**不是fea/factors**。artifacts/backups目前子项0；resources含167学习资料，其中5py/99txt/63pdf，并非全部失败生成物，不能整体删。

最关键父子依赖：

- cp_momentum_lowvol_20需要未通过的momentum_20与通过的idio_vol_60。
- cp_value_momentum_div需要未通过的bp与momentum_20。
- mf_flow_factor_momentum_20依赖未通过的mf_net_inflow_ratio，但其年度C6/8很可能最终拒绝，未批准时无需额外私有化其父项。
- 不能为了子项保留父项独立注册/数据，需改成未注册私有数学基元，更新真实deps并重新验证。

**已完成的只读可行性，不是生产修改或G1：**
- V2 `cleanup_parent_feasibility_v2.py`：bp/momentum_20全9年18项父value/key/NaN精确一致，`cleanup_parent_feasibility_result_v2.json` complete_readonly_value_parity。
- V3 `cleanup_child_feasibility_v3.py` + `cleanup_parent_panel_values.py`：两个子项全部9年18项value/rank/key/NaN精确一致，`cleanup_child_feasibility_result_v3.json` complete_readonly_child_value_and_rank_parity，所有比较true。
- V2 peak charged28.637032448GB、anon7.646437376GB；V3 charged31.117111296GB、anon10.052333568GB，均正常退出。
- V1错误导入fea.dates.minus_days，在任何数值计算前失败；V2改从fea.engine导入。不要拿V1当有效结果。

私有基元需保持父原来的年度anchor/default2018，mom warmup56天、bp700天，每个子年度新Engine；bp原full金融字段配置不可缩成错误空字段；使用原UNIVERSE遮罩，并在送入子项前先float32舍入，pre2018保持NaN，以复现原Store读取语义。mom20是原_ret_k的expm1(roll_sum(log1p(ret1)))并带零交易窗口遮罩，不是直接ctx.ret20；bp用point(total_hldr_eqy_exc_min_int)/(px_close*total_share)，min_abs_den1e6。RAW访问记录仍需捕获。

原生生命周期必须尊重：

1. main.py生产使用排他daily.lock，消费发布使用共享锁并拒绝dirty/inflight。
2. 原生set_status retired会拒绝仍有production子项依赖的父项；先更新并原生批准子项真实deps，再退休父项。
3. `fea/release.accept_existing`当前更新approvedhash/version/event但**不传播deps到metadata**；已准备最小修复草稿item.update加 `deps=list(REGISTRY[name].deps)`。实际实施后做原生“有子依赖阻断退休→批准新deps→可退休”的有意义测试，不能手改approved哈希或journal。
4. legacy定义变化需要version++。身份按整个模块AST，不只是函数body；删同模块失败函数也可能影响保留项身份。明确版本与新审批，保持原数值全量parity。注释不计、docstring会计。
5. COMMON定义只哈希fea列举的共同kernel AST，**不哈希conf/field_expansion.json**；删未批准的annual目录项可保留不变factory的数值身份，别无故改共同数学kernel。release.py不在COMMON。
6. 原生publish的state/publication_hashes.json会保留旧项；用户授权下删除该过时生成缓存，再调用nativepublish重新计算当前项即可。不要手工伪写发布manifest、cachehash或事件日志。
7. 研究catalog的family源码全FILE SHA不可变，不能把旧family删分支再手补旧SHA。批准研究项应迁移到新不可变精简family/版本，保持参数与方向，真实新G1+旧生产全量精确parity后，走qualified→shadow→production，再退休旧候选。
8. 保留研究预计4项在3文件：selection_20261001_v1.py中fragility/HHI；r2_ownership_v2.py中trend_persistence(k4)；r3_intraday_moments_v2.py中rv_skewness。需原名→新hash后缀名crosswalk，最终数量按原554决策计，不双计迁移。
9. dynamic factory也需清：annual_field_expansion的conf/field_expansion.json共136项；momentum20/60/120/250注册循环；tradability注册表；__init__.py实际保留模块导入。sector、field_events/field_markets先核对跨模块依赖；market仍需要_div/_gt等原语。
10. scripts/prune_factors.py --apply当前禁用且旧阈值不适用，不能启用它来代替物理清理。
11. scripts/run_tests.py为必要检查；env_invariance_test.py硬编码mom20/mom120/reversal2等，应按最终保留范围做合适调整，不能让测试继续依赖已经删除的独立对象。
12. 改公式/依赖的cp、迁移研究项需要真实新原生G1与旧值/rank精确parity；仅删死代码的数值不变项也需要确认身份、审批和全量原值parity，别无依据重跑全部统计或假复用旧hash。

## 9. 已落盘的准备脚本：草稿、未运行、不能盲用

原本只在本地的8个草稿已复制到 `B/resume_preparation/`，无凭据：

| 文件 | 用途与运行条件 |
| --- | --- |
| final_mechanism_review.py | 554逐项最终判定草稿；需要complete_reassessment。原脚本输入是同目录mirror，服务器无此布局，先适配路径为B，另存版本、保留真实证据。 |
| cleanup_static_proposal.py | 最终决策后输出静态删除提案，不实际应用，报告动态factory/跨导入/版本问题。 |
| cleanup_run_guard.py | 后续自有原生命令资源保护包装，0.25秒/50.5GB charged/48GB anon，只停止所属PG；先读参数接口。 |
| prepare_private_coupling_basis.py | 两cp批准且真实V3=18项精确通过后生成coupling草稿，私有basis enabled=False未注册，version++，未覆盖生产。 |
| prepare_dependency_metadata_fix.py | accept_existing deps传播最小补丁提案，未应用，需原生生命周期测试。 |
| make_delivery.py | 最终CSV/TXT草稿，原路径为本地work/mirror与outputs，服务器使用需适配。 |
| pack_cleanup_delivery.py | 实际清理成功后生成纯文档证据包，不含.py/.pyc/Parquet/npy/npz/bin或密钥。 |
| validate_delivery.py | 决策/清理/发布/名称映射一致性核对，不能在清理未做时给成功结论。 |

服务器B内V2/V3验证、盘点和原数值审计脚本都已有持久化。**旧pack_delivery.py会备份失败源码/数据，已废弃，禁止使用。** 本节草稿不属于原36数值冻结源码，复制是为交接，不代表实现完成。任何草稿有finalize/cleanup_summary断言失败，都不能删断言伪装完成。

## 10. 续做顺序与完成标准

A. 完成第6节全部剩余原版验证，保留可核验旧完成证据，更新review。
B. 逐项运行最终机制审议，特别两期限C、4机制待证、11Revise；生成 `B/delivery/final_mechanism_review.json`，记录554原对象 approved_for_retention/cleanup_action，不豁免失败控制。
C. 根据最终保留集调整清理提案、必要私有cp基元、deps原生传播修复、研究精简新版本。应用前完成可核对的原名/文件/依赖闭包清单；无需再问已授权的清理。
D. 真实运行新版本G1、生产全量float32 value/rank/键/NaN精确parity及必要检查；用原生审核/状态转换更新依赖，再退休未批准对象及旧研究版本。别先把必要父数据删掉导致尚未验过的新子实现没有比较基准。
E. 物理删除所有未批准独立脚本/函数/factory项/正式data/state、失败/废弃研究alias/trial数据、其审计源快照和缓存；抽出纯文档指标与解释。保留批准对象必要原语、共享RAW和相关保留配置。共享scratch目录只删明确归本任务失败对象的部分。
F. 原生重新发布、注册与当前发布集合一致、失败独立对象与生成路径剩余0、依赖闭包/导入检查通过、新生产值与原批准值精确一致。原名映射到新当前名双射。
G. 实际写cleanup_summary.json，只有真完成才能status=complete_verified_cleanup：
   - retained_names与removed_names对原554全集互斥且合计554；
   - name_mapping仅批准原名、双射到current_registry_names=current_release_names；
   - failed_registered_objects_remaining=0，failed_generated_paths_remaining=0；
   - partition_content_exactly_preserved=true，production_import_and_required_checks_passed=true；
   - current_release_id与真实原生新发布一致；
   - resources.peak_charged_bytes≤60,000,000,000；
   - 最终manual批准集合完全对应retained_names。
H. 再生成因子复审总表.csv、因子工程复审报告.txt、因子复审证据包.zip、交付核对记录.json。CSV写原名/清理后名、RAW/DECLIC/FM/t/分年/控制/G5/G1身份、最终批准、已执行清理结果；TXT写规则/边界/实际资源/新发布/实际删除；ZIP纯文档与JSON指标身份，不含失败源码或数据。关键证据服务器B/delivery、临时localtmp及客户端outputs三处保存。**这些最终交付目前都未生成。**

## 11. 经验教训，避免再次踩坑

- 曾在producer运行时添加审计adapter触发源码一致性保护，属于启动顺序错误。后续完成原生4worker全量恢复。今后先停变更窗口、封存来源再计算；不能边生产边改共同身份。
- 恢复中rel_turnover_ind_20d的2022/2023/2025三年分区确实重写过，4933分区相同跳过；本轮统计用当前恢复值。不能声称旧数据全部未动，或旧幅度已追溯恢复。恢复成功不等于严格G1通过。
- 共享FUSE上V3状态atomic rename曾失败，旧driver退出但数学继续约13GB；后续独立guard采用，中间约2分钟保护间隙，不能声称历史保护从未中断。重启恢复要保护先行，权威控制状态放本地tmp并复制持久记录，处理rename/可见性故障。
- V8采用前snapshot竞态导致preflight失败，发生在handoff前，旧控制器恢复且数学没重启；V9改为暂停后动态捕获。采用活进程时检查start time、实际PG，不能沿用旧静态名单。现在所有进程已停，恢复不采用旧PID。
- G5内存与速度优化保持精确：顺序mmap、原生float32 rank、ordinalcounter。曾先用float64产生约1.9e-7差异，改为原生float32精确后才启用；不允许近似相关替代审核。
- 原生数值trial新子进程解决累积RLIMIT_AS问题，不提高24GiB限制。机器还有空闲CPU并不意味着可跳过重源10分钟冷缓存/anon评估。
- RAW input checksum cache只复用原生MD5/size/mtime有效元数据，失效规则和重新MD5仍原生执行；不是复用因子值来伪验证因果。
- 完成trial的posix_fadvise只建议释放只读页缓存，内容/文件身份不变；不能把建议当作精确释放字节。DERIVED回收仅限明确完成sealed候选、不在run.output_hashes中的自有缓存，前后验证RAW可见性；初期财务回收为0时未声称释放空间。
- 主动关机停止与因子合同失败区分；worker进度passed:false不是审批结论。没有sealedrun或完整verification就仍pending。
- 文档应区分已运行、草稿、只读可行性、原生G1、最低统计资格、最终批准和实际清理。不要以“有提案”写成“已经删完”，不要以“年度分区写出”写成“新增因子通过”。

## 12. 接手时最有用的证据索引

均相对B：
- user_stop_snapshot_20261002.json：完整停止前controller/adoption/数学PG/请求/完成79目标/未完成12目标/辅助停止记录/最终0进程。
- driver_state.json：停止状态；不要用重启后的/tmp残留覆盖它。
- freeze.json：554原始对象、分区、源身份；screen/<name>.json、review.json/review.csv：原始筛选结论。
- engineering/plan.json、<name>.json、phase_*_request/result.json及phase日志：原生验证证据；完整runs在ROOT/artifacts/research/runs。
- engineering_parallel_amendment_v13.json：冻结36源码；parallel_adoption_v13.json、parallel_handoff_record_v13.json：历史采用记录；handoff SHA e3b37e78fc213669d77bc3996cf4ebd45ff218af9579e3bed79ba005cf638407。
- engineering/elastic_progress_v10_heavy.json及前序V8/V9进度：真实并行升级；resource_observations.json：资源峰值/生产恢复历史。
- cleanup_preinventory.json、cleanup_scope_inventory.json、cleanup_source_plan.json：只读盘点。
- cleanup_parent_feasibility_result_v2.json、cleanup_child_feasibility_result_v3.json及对应resources/source封存：私有基元只读精确可行性。
- mechanism_candidates.json：源内容与机制原始收集，只用于审议，后续按用户要求剔除不批准源码内容。
- resume_preparation/：8个未执行草稿及交接准备清单。

**交接结束状态：已停算、已停监控、已持久化；5项正在运行的阶段已中断，12项G1仍待完成；最终审批/物理清理/新发布/最终交付全部未完成。接手Agent得到继续指令后按上述顺序推进。**

